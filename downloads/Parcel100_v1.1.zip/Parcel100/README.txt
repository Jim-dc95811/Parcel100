Parcel100 1.1

Purpose
-------
Build 100 small ArcGIS Earth-ready GeoJSON parcel files from one Master 4
1-degree box. Cell numbering matches the existing Master4 Grid Maker.

No QGIS project is required for production.
No third-party Python packages are required.

Quick start
-----------
1. Run Parcel100.bat.
2. Enter Master 4 coordinates, for example: 82w,81w,30n,31n
3. Paste a public ArcGIS FeatureServer polygon layer URL ending in /FeatureServer/<layer id>.
4. Click Read Service.
5. Select only the fields you want carried into ArcGIS Earth.
6. Choose an output folder.
7. Click BUILD 100 GEOJSON FILES.

Florida preset
--------------
The program starts with the current Florida statewide parcel layer used during
development:
https://services5.arcgis.com/GcvM6vDlR2gM4x31/arcgis/rest/services/FL_Parcels/FeatureServer/0

The program reads the service metadata itself. For other states or counties,
replace the URL with their public ArcGIS FeatureServer polygon layer.

Output naming
-------------
Example Master 4: 82w,81w,30n,31n
W082W081N031N030-001-Parcels.geojson
...
W082W081N031N030-100-Parcels.geojson

Each file is WGS 84 / EPSG:4326 GeoJSON for direct use in ArcGIS Earth.

Notes
-----
- The tool requests only the selected attributes, reducing file size.
- Each cell query is spatially limited to its 0.1-degree Master 4 cell.
- A parcel crossing a cell boundary can exist in both neighboring files. That
  preserves complete parcel geometry when a cell is loaded by itself.
- Empty cells are detected by the lightweight ID query and skipped. No empty
  GeoJSON file is written for ocean/out-of-coverage cells.
- A failed service request is still treated as an error, not as an empty cell.
- Public FeatureServer access is required while building the files. The output
  GeoJSON files themselves are local/offline.
